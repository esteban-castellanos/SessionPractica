let mainController = {
    index: function(req,res){
        res.render('index', {color: req.session.color});
    },
    color: function(req,res){
         req.session.color = req.body.color;
         res.redirect('/');
    },
    borrar: function(req,res){

    },
    queColorEs: function(req,res){
        res.render('queColorEs', {color: req.session.color});
    }
}

module.exports = mainController;