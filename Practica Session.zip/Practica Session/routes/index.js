var express = require('express');
var router = express.Router();
var mainController = require('../Controllers/mainController');

router.get('/', mainController.index); 
router.post('/color', mainController.color);

router.get('/borrar', mainController.borrar);
router.get('/queColorEs', mainController.queColorEs); 

module.exports = router;
